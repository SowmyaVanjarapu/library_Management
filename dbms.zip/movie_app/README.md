# Movie Media Upload App

## Description
Simple Flask-based application to upload movie images/videos and view them.

## Setup
1. Install Python packages:
   pip install -r requirements.txt

2. Run:
   python app.py

3. Visit:
   http://your-server-ip:5000

## Technologies
- Python
- Flask
- SQLite
- Bootstrap 5
- Waitress WSGI server (for production)

from flask import Flask, request, redirect, render_template, url_for
import mysql.connector
import os
from datetime import datetime
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100 MB limit
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'mp4', 'mov'}

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# 🔵 MySQL connection details (Change these!)
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Surya@1234",
    database="movie_db"
)
cursor = db.cursor()

# 🧩 Create table if not exists
cursor.execute('''
    CREATE TABLE IF NOT EXISTS Media (
        MediaID INT PRIMARY KEY AUTO_INCREMENT,
        FileName VARCHAR(255) NOT NULL,
        MediaType VARCHAR(50) NOT NULL,
        FilePath VARCHAR(500) NOT NULL,
        UploadDate DATETIME NOT NULL
    )
''')
db.commit()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        file = request.files['file']
        media_type = request.form['media_type']

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            insert_query = '''
                INSERT INTO Media (FileName, MediaType, FilePath, UploadDate)
                VALUES (%s, %s, %s, %s)
            '''
            values = (filename, media_type, filepath, datetime.now())
            cursor.execute(insert_query, values)
            db.commit()

            return redirect(url_for('index'))

    select_query = 'SELECT * FROM Media'
    cursor.execute(select_query)
    media_files = cursor.fetchall()

    return render_template('index.html', media_files=media_files)

@app.route('/delete/<int:media_id>', methods=['GET'])
def delete_media(media_id):
    cursor = db.cursor()

    # Step 1: Get the file path of the media
    cursor.execute("SELECT FilePath FROM Media WHERE MediaID = %s", (media_id,))
    result = cursor.fetchone()

    if result:
        file_path = result[0]
        
        # Step 2: Delete the physical file
        try:
            os.remove(file_path)
        except FileNotFoundError:
            pass  # If file already missing, ignore

        # Step 3: Delete database record
        cursor.execute("DELETE FROM Media WHERE MediaID = %s", (media_id,))
        db.commit()

    cursor.close()
    return redirect('/')

if __name__ == '__main__':
    print("🚀 Server is starting on http://localhost:5000 ...")
    from waitress import serve
    serve(app, host='0.0.0.0', port=5000)

